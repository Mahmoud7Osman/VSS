from pibyone import loader

loader.exec_load("Preparing Payload... ",3)
loader.exec_load("Preparing address... ",3)
loader.exec_load("Spawning  Payload... ",3)
loader.simple_load("Checking",1.17,colors=True)
loader.eq_load("Writing Dropper ",3)
