from pibyone import loader

loader.transfer_load("Payload Data","Shell file",3,fail=False)

