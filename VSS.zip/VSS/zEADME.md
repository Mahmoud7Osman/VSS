# Vairous7x SupperSploit
---------------------------Subscribe to Vairous7x on Youtube----------------------------- 

run 'bash setup.sh' 

then run 'bash vcs.sh'

type 'full_guide' to learn usage

type 'help' to show commands

---------------------------Subscribe to Vairous7x on Youtube------------------------------
